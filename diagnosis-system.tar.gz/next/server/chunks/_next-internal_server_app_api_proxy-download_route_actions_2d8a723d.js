module.exports=[93179,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proxy-download_route_actions_2d8a723d.js.map