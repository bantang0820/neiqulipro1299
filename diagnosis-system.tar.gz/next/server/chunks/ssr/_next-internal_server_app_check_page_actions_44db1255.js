module.exports=[91088,a=>{"use strict";var b=a.i(56004);a.s([],54893),a.i(54893),a.s(["400ed029792a98f43d3ec15e59e18f481858602221",()=>b.checkSubmission],91088)}];

//# sourceMappingURL=_next-internal_server_app_check_page_actions_44db1255.js.map