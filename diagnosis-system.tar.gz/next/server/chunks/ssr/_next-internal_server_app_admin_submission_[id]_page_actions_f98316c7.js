module.exports=[18093,a=>{"use strict";var b=a.i(56004);a.s([],30071),a.i(30071),a.s(["405684bf3a4009f7c9533dd43ccdd08d82458db83c",()=>b.uploadReport],18093)}];

//# sourceMappingURL=_next-internal_server_app_admin_submission_%5Bid%5D_page_actions_f98316c7.js.map