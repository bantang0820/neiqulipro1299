module.exports=[57526,a=>{"use strict";var b=a.i(56004);a.s([],71570),a.i(71570),a.s(["40ad84f02a6513af2550a4ef46b09be2051aca0c79",()=>b.submitSurvey],57526)}];

//# sourceMappingURL=_next-internal_server_app_page_actions_8d6da72e.js.map