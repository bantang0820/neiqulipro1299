globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d59f830a2b8e768c.js",
    "static/chunks/c754c85b710f8b09.js",
    "static/chunks/cc759f7c2413b7ff.js",
    "static/chunks/c87b0ad71ec740b6.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/turbopack-350d2975d6856f49.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];