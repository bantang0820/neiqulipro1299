var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy-download/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_f65a32f5.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_proxy-download_route_actions_2d8a723d.js")
R.m(80866)
module.exports=R.m(80866).exports
